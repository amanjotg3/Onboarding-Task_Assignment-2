﻿using MarsFramework.Global;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Threading;
using AutoItX3Lib;

namespace MarsFramework
{
    class ShareSkill
    {
        public ShareSkill()
        {
            PageFactory.InitElements(Global.GlobalDefinitions.driver, this);
        }

        #region  Initialize Web Elements 
        //Finding Share Skill button
        [FindsBy(How = How.XPath, Using = "//*[@id='account-profile-section']/div/section[1]/div/div[2]/a")]
        private IWebElement shareskill { get; set; }

        //Finding title textbox
        [FindsBy(How = How.XPath, Using = "//*[@id='service-listing-section']/div[2]/div/form/div[1]/div/div[2]/div/div[1]/input")]
        private IWebElement title { get; set; }

        //Finding description textbox
        [FindsBy(How = How.XPath, Using = "//*[@id='service-listing-section']/div[2]/div/form/div[2]/div/div[2]/div[1]/textarea")]
        private IWebElement description { get; set; }

        //Finding Category dropdown
        [FindsBy(How = How.XPath, Using = "//*[@id='service-listing-section']/div[2]/div/form/div[3]/div[2]/div/div[1]/select")]
        private IWebElement dropdown_cat { get; set; }

        //Select the Category value from the dropdown 
        [FindsBy(How = How.XPath, Using = "//*[@id='service-listing-section']/div[2]/div/form/div[3]/div[2]/div/div[1]/select/option[9]")]
        private IWebElement dropdownvalue_cat { get; set; }

        //Finding Sub Category dropdown
        [FindsBy(How = How.XPath, Using = "//*[@id='service-listing-section']/div[2]/div/form/div[3]/div[2]/div/div[2]/div[1]/select")]
        private IWebElement dropdown_subcat { get; set; }

        //Select the Sub Category value from the dropdown 
        [FindsBy(How = How.XPath, Using = "//*[@id='service-listing-section']/div[2]/div/form/div[3]/div[2]/div/div[2]/div[1]/select/option[7]")]
        private IWebElement dropdownvalue_subcat { get; set; }

        //Finding Tags textbox
        [FindsBy(How = How.XPath, Using = "//*[@id='service-listing-section']/div[2]/div/form/div[4]/div[2]/div/div/div/div/input")]
        private IWebElement tag { get; set; }

        //Finding Service type radio button
        [FindsBy(How = How.XPath, Using = "//*[@id='service-listing-section']/div[2]/div/form/div[5]/div[2]/div[1]/div[1]/div/input")]
        private IWebElement service_type { get; set; }

        //Finding Location type radio button
        [FindsBy(How = How.XPath, Using = "//*[@id='service-listing-section']/div[2]/div/form/div[6]/div[2]/div/div[2]/div/input")]
        private IWebElement location_type { get; set; }

        //Finding Start date textbox
        [FindsBy(How = How.XPath, Using = "//*[@id='service-listing-section']/div[2]/div/form/div[7]/div[2]/div/div[1]/div[2]/input")]
        private IWebElement start_date { get; set; }

        //Finding Sun start time textbox
        [FindsBy(How = How.XPath, Using = "//*[@id='service-listing-section']/div[2]/div/form/div[7]/div[2]/div/div[2]/div[2]/input")]
        private IWebElement sun_start { get; set; }

        //Finding Sun end time textbox
        [FindsBy(How = How.XPath, Using = "//*[@id='service-listing-section']/div[2]/div/form/div[7]/div[2]/div/div[2]/div[3]/input")]
        private IWebElement sun_end { get; set; }

        //Finding Skill Trade radio button
        [FindsBy(How = How.XPath, Using = "//*[@id='service-listing-section']/div[2]/div/form/div[8]/div[2]/div/div[1]/div/input")]
        private IWebElement skill_trade { get; set; }

        //Finding Skill-Exchange textbox
        [FindsBy(How = How.XPath, Using = "//*[@id='service-listing-section']/div[2]/div/form/div[8]/div[4]/div/div/div/div/div/input")]
        private IWebElement skill_exchange { get; set; }

        //Finding Work Samples + icon
        [FindsBy(How = How.XPath, Using = "//*[@id='service-listing-section']/div[2]/div/form/div[9]/div/div[2]/section/div/label/div/span/i")]
        private IWebElement work_sample { get; set; }

        //Finding Active radio button
        [FindsBy(How = How.XPath, Using = "//*[@id='service-listing-section']/div[2]/div/form/div[10]/div[2]/div/div[1]/div/input")]
        private IWebElement active { get; set; }

        //Finding Save button
        [FindsBy(How = How.XPath, Using = "//*[@id='service-listing-section']/div[2]/div/form/div[11]/div/input[1]")]
        private IWebElement save { get; set; }

        //Finding Manage Listings tab
        //[FindsBy(How = How.XPath, Using = "//*[@id='listing-management-section']/section[1]/div/a[3]")]
        [FindsBy(How = How.XPath, Using = "//div[@class='ui eight item menu']//a[3]")]
        private IWebElement manage_listings { get; set; }

        //Finding edit button of the list to change
        [FindsBy(How = How.XPath, Using = "//*[@id='listing-management-section']/div[2]/div[1]/table/tbody/tr[1]/td[8]/i[2]")]
        private IWebElement edit_list { get; set; }

        //Finding Service type radio button to be edited
        [FindsBy(How = How.XPath, Using = "//*[@id='service-listing-section']/div[2]/div/form/div[5]/div[2]/div[1]/div[2]/div/input")]
        private IWebElement edit_service_type { get; set; }

        //Finding delete button of the list to be deleted
        [FindsBy(How = How.XPath, Using = "//*[@id='listing-management-section']/div[2]/div[1]/table/tbody/tr/td[8]/i[3]")]
        private IWebElement delete_list { get; set; }

        //Finding accept button of the list to be deleted
        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div[3]/button[2]")]
        private IWebElement delete_alert { get; set; }

        #endregion

        public void SharingSkill()
        {
            GlobalDefinitions.driver.Manage().Window.Maximize();

            //Populate the excel data
            GlobalDefinitions.ExcelLib.PopulateInCollection(Base.ExcelPath, "ShareSkill");
            Thread.Sleep(400);

            //Clicking on Share Skill button
            shareskill.Click();
            Thread.Sleep(200);

            //Enter Title
            title.SendKeys(GlobalDefinitions.ExcelLib.ReadData(2, "Title"));
            Console.WriteLine("Title");

            //Enter Description
            description.SendKeys(GlobalDefinitions.ExcelLib.ReadData(2, "Description"));
            Console.WriteLine("Description");


            //Click on Category dropdown
            dropdown_cat.Click();
            Console.WriteLine("Category");

            //Select the Category from dropdown list
            dropdownvalue_cat.Click();
            Console.WriteLine("Category Value");

            //Click on Sub Category dropdown
            dropdown_subcat.Click();
            Console.WriteLine("SubCategory");

            //Select the Sub Category from dropdown list
            dropdownvalue_subcat.Click();
            Console.WriteLine("SubCategory Value");

            //Enter Tags
            tag.SendKeys(GlobalDefinitions.ExcelLib.ReadData(2, "Tags"));
            tag.SendKeys(Keys.Enter);
            Thread.Sleep(300);
            Console.WriteLine("tags");

            //Selecting Service type
            service_type.Click();
            Console.WriteLine("Service Type");

            //Selecting Location type
            location_type.Click();
            Console.WriteLine("Location Type");

            //Enter Start Date
            //start_date.SendKeys(Global.ExcelLib.ReadData(2, "Start Date"));
            start_date.SendKeys("03-09-2019");
            Console.WriteLine("Start Date");

            //Enter Sun start time
            //sun_start.SendKeys(GlobalDefinitions.ExcelLib.ReadData(2, "Sun_Start"));
            sun_start.SendKeys("05:30");
            Console.WriteLine("Sun Start");

            //Enter Sun end time
            //sun_end.SendKeys(GlobalDefinitions.ExcelLib.ReadData(2, "Sun_End"));
            sun_end.SendKeys("07:30");
            Console.WriteLine("Sun End");

            //Selecting Skill Trade
            //skill_trade.Click();
            //Console.WriteLine();

            //Enter Skill Exchange tag
            skill_exchange.SendKeys(GlobalDefinitions.ExcelLib.ReadData(2, "Skill Exchange"));
            skill_exchange.SendKeys(Keys.Enter);
            Thread.Sleep(300);
            Console.WriteLine("Skill Exchange");

            //Uploading work sample
            //Clicking on + icon
            work_sample.Click();
            AutoItX3 autoIt = new AutoItX3();
            autoIt.WinActivate("Open");
            autoIt.Send("C:\\Users\\Dell\\Pictures\\Saved Pictures\\image1.jpg\\");
            Console.WriteLine("Image Selected");

            Thread.Sleep(300);
            autoIt.Send("{Enter}");
            Thread.Sleep(200);
            Console.WriteLine("Image Uploaded");

            //Selecting Active
            active.Click();
            Thread.Sleep(300);
            Console.WriteLine("Active button");

            //Clicking on save button
            save.Click();
            Thread.Sleep(5000);
            Console.WriteLine("Save button");

            //Verification
            //Start the share Skill test
            Base.test = Base.extent.StartTest("Share Skills");

            string message = Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='listing-management-section']/div[2]/div[1]/table/tbody/tr[1]/td[3]")).Text;
            string ActualMessage = "Pizza Making";

            //Explicit Wait
            Thread.Sleep(2000);

            try
            {
                if (message == ActualMessage)
                {
                    Base.test.Log(RelevantCodes.ExtentReports.LogStatus.Pass, "Verification: Skill Shared");
                    Console.WriteLine("Verification: Skill shared");
                    GlobalDefinitions.SaveScreenShotClass.SaveScreenshot(Global.GlobalDefinitions.driver, "Share Skill verified");
                }
                else
                {
                    Base.test.Log(RelevantCodes.ExtentReports.LogStatus.Fail, "Verification: Skill not shared");
                    Console.WriteLine("Verification: Skill not shared");
                }
            }
            catch (Exception)
            {
                throw;
            }

        }

        public void EditListings()
        {
            //Maximize the window screen
            GlobalDefinitions.driver.Manage().Window.Maximize();

            //Click on Manage Listings tab
            manage_listings.Click();
            Thread.Sleep(200);

            //Click on edit button of the list to be edited
            edit_list.Click();

            //Click on service type
            edit_service_type.Click();

        }

        public void DeleteListings()
        {
            //Maximize the window screen
            //GlobalDefinitions.driver.Manage().Window.Maximize();

            //Click on Manage Listings tab
            manage_listings.Click();
            Thread.Sleep(200);

            //Delete the list
            delete_list.Click();
            Thread.Sleep(200);
            //GlobalDefinitions.driver.SwitchTo().Alert().Accept();
            delete_alert.Click();
            Thread.Sleep(300);


            //Verification
            try
            {
                string message = Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='listing-management-section']/div[2]/h3")).Text;
                string ActualMessage = "You do not have any service listings!";

                if (message == ActualMessage)
                {
                    Base.test.Log(RelevantCodes.ExtentReports.LogStatus.Pass, "Verification: Skill deleted");
                    Console.WriteLine("Verification: Skill deleted");
                }

                else
                {
                    Base.test.Log(RelevantCodes.ExtentReports.LogStatus.Fail, "Verification: Skill not deleted");
                    Console.WriteLine("Verification: Skill not deleted");
                }
            }
            catch (Exception)
            {
                throw;
            }

        }
    }

}
