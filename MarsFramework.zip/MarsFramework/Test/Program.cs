﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsFramework
{
    public class Program
    {
        [TestFixture]
        [Category("Sprint1")]
        class User : Global.Base
        {

            //[Test]
            //public void UserAccount()
            //{
            //    // Creates a toggle for the given test, adds all log events under it    
            //    test = extent.StartTest("Create an Account");

            //    // Create an class and object to call the method
            //    Profile obj = new Profile();
            //    obj.EditProfile();

            //}

            //Test case 1: Share a skill
            [Test]
            public void ShareSkill()
            {
                // Creates a toggle for the given test, adds all log events under it    
                test = extent.StartTest("Share a skill");

                // Create an class and object to call the method
                ShareSkill obj = new ShareSkill();
                obj.SharingSkill();

            }

            //Test case 2: Edit a Listing
            [Test]
            public void EditList()
            {
                //Start the create profile test
                test = extent.StartTest("Edit a List");

                //Creating a Class
                ShareSkill obj = new ShareSkill();

                //Creating Method
                obj.EditListings();

            }

            //Test case 3: Deactivating a Listing
            [Test]
            public void DeleteList()
            {
                //Start the delete list test
                test = extent.StartTest("Delete a List");

                //Creating a Class
                ShareSkill obj = new ShareSkill();

                //Creating Method
                obj.DeleteListings();
            }
        }
    }
}